import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var imagen: UIImageView!
    @IBOutlet weak var etiqueta: UILabel!
    @IBOutlet weak var Validacion: UILabel!
    @IBOutlet weak var Entrada: UITextField!
    
    let listaDeElementos = [
        "Alexander Volkanovski",
        "Charles Oliveira",
        "Conor McGregor",
        "Diego Lopez",
        "Dustin Poirier",
        "Ilia Topuria",
        "Islam Makhachev",
        "Michael Chandler",
        "Tony Ferduson",
        "Yahir Rodrigez"
    ]
    
    var elementosIndice = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        actualizarElemento()
    }

    @IBAction func mostrar(_ sender: Any) {
        // Obtener el texto ingresado por el usuario
        guard let entradaUsuario = Entrada.text else {
            Validacion.text = "Por favor, ingresa un nombre."
            return
        }

        // Obtener el nombre correcto desde la lista
        let nombreCorrecto = listaDeElementos[elementosIndice]

        // Comparar ignorando mayúsculas y espacios
        if entradaUsuario.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() ==
            nombreCorrecto.lowercased() {
            Validacion.text = "✅ Nombre correcto"
        } else {
            Validacion.text = "❌ Nombre incorrecto"
        }

        // (Opcional) Mostrar la respuesta correcta
        etiqueta.text = nombreCorrecto
    }

    @IBAction func siguiente(_ sender: Any) {
        elementosIndice += 1
        if elementosIndice >= listaDeElementos.count {
            elementosIndice = 0
        }
        actualizarElemento()
    }

    func actualizarElemento() {
        etiqueta.text = "¿Quién es este peleador?"
        Validacion.text = ""
        Entrada.text = ""

        let nombreDelElemento = listaDeElementos[elementosIndice]
        let laImagen = UIImage(named: nombreDelElemento)
        imagen.image = laImagen
    }
}

