import UIKit

class ViewController: UIViewController {
    //Conexion con el objeto UIImageView
    @IBOutlet weak var imagen: UIImageView!
    //Conexion con el objeto Label
    @IBOutlet weak var etiqueta: UILabel!
    
    let listaDeElementos = ["ilia1","ilia2","ilia3","ilia4"]
    var elementosIndice = 0
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    actualizarElemento()
    }
    
    //Conexion con la objeto Mostrar
    @IBAction func mostrar(_ sender: Any) {
        etiqueta.text = listaDeElementos[elementosIndice]
    }
    //Conexion con el objeto Siguiente->
    @IBAction func siguiente(_ sender: Any) {
        
        elementosIndice += 1
        if elementosIndice >= listaDeElementos.count {
            elementosIndice = 0
        }
        actualizarElemento()
    }
    
    func actualizarElemento(){
        etiqueta.text = "?"
        let nombreDelElemento = listaDeElementos[elementosIndice]
        
        let laImagen = UIImage(named: nombreDelElemento)
        imagen.image = laImagen
        
    }
}

