import UIKit

class ViewController: UIViewController {
    
    //slider para timido
    @IBOutlet weak var timidSlider: UISlider!
    //slider para curioso
    @IBOutlet weak var curiousSlider: UISlider!
    //slider para seguridad
    @IBOutlet weak var confidentSlider: UISlider!
    
    //Penudo
    @IBOutlet weak var timidLabel: UILabel!
    //Curioso
    @IBOutlet weak var curiousLabel: UILabel!
    //Seguridad
    @IBOutlet weak var confidentLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        // Configura los valores iniciales de los sliders
        timidSlider.value = 5
        curiousSlider.value = 5
        confidentSlider.value = 5
        // Muestra los valores iniciales en los labels
        updateLabels()
        
    }
    // MARK: - Acción común cuando se mueve cualquier slider
    @IBAction func sliderChanged(_ sender: UISlider) {
        // Redondear el valor del slider al número entero más cercano
        let roundedValue = round(sender.value)
        sender.setValue(roundedValue, animated: false)
        
        // Actualizar los labels según cuál slider se movió
        if sender == timidSlider {
            timidLabel.text = "Tímido: \(Int(roundedValue))"
        } else if sender == curiousSlider {
            curiousLabel.text = "Curioso: \(Int(roundedValue))"
        } else if sender == confidentSlider {
            confidentLabel.text = "Seguro: \(Int(roundedValue))"
        }
    }
    
    // MARK: - Actualiza todos los labels (la usamos al inicio)
    func updateLabels() {
        timidLabel.text = "Tímido: \(Int(timidSlider.value))"
        curiousLabel.text = "Curioso: \(Int(curiousSlider.value))"
        confidentLabel.text = "Seguro: \(Int(confidentSlider.value))"
    }
    
    // MARK: - Botón "Ver resultado"
    @IBAction func showResult(_ sender: UIButton) {
        // Obtener los valores actuales de los sliders
        let timid = timidSlider.value
        let curious = curiousSlider.value
        let confident = confidentSlider.value
        
        // Determinar qué rasgo domina
        var result = "3"
        print("\(result)")
        if timid > curious && timid > confident {
            result = "Pichu"        // más tímido
        } else if curious > timid && curious > confident {
            result = "Pikachu"      // más curioso
        } else {
            result = "Raichu"       // más seguro / confiado
        }
        
        // Mostrar la vista correspondiente (según tus segues "Present Modally")
        switch result {
        case "Pichu":
            performSegue(withIdentifier: "showPichu", sender: self)
        case "Pikachu":
            performSegue(withIdentifier: "showPikachu", sender: self)
        case "Raichu":
            performSegue(withIdentifier: "showRaichu", sender: self)
        default:
            break
        }
    }
}
