//
//  AdivinaQuienTests.swift
//  AdivinaQuienTests
//
//  Created by CEDAM17 on 05/11/25.
//

import Testing
@testable import AdivinaQuien

struct AdivinaQuienTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
