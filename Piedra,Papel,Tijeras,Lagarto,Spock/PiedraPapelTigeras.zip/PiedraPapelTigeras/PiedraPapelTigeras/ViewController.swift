//
//  ViewController.swift
//  PiedraPapelTigeras
//
//  Created by DEVELOP17 on 22/10/25.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labelOponente: UILabel! //Tu oponente eligio
    
    
    @IBOutlet weak var labelEleccion: UILabel!//Tu eleccion fue
    
    
    @IBOutlet weak var labelResultado: UILabel! //Resultado
    
    enum Eleccion: String, CaseIterable {
            case piedra = "Piedra"
            case papel = "Papel"
            case tijeras = "Tijeras"
            case lagarto = "Lagarto"
            case spock = "Spock"
        } //Declaracion de variables "objetos" con los que jugaremos
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        labelOponente.text = "El oponente eligió:"
                labelResultado.text = "Resultado:"
        labelEleccion.text = "Tu eligiste:"
        
    }
    
    func jugar(usuario: Eleccion) {
            let oponente = Eleccion.allCases.randomElement()!
        
        labelEleccion.text = "Tu eleccion fue: \(usuario.rawValue)"
            labelOponente.text = "El oponente eligió: \(oponente.rawValue)"
            

            if usuario == oponente {
                labelResultado.text = "¡Empate!"
            } else if gana(usuario, a: oponente) {
                labelResultado.text = "¡Ganaste!"
            } else {
                labelResultado.text = "Perdiste"
            }
        }
    
    func gana(_ jugador: Eleccion, a oponente: Eleccion) -> Bool {
            switch jugador {
            case .tijeras:
                return oponente == .papel || oponente == .lagarto
            case .papel:
                return oponente == .piedra || oponente == .spock
            case .piedra:
                return oponente == .lagarto || oponente == .tijeras
            case .lagarto:
                return oponente == .spock || oponente == .papel
            case .spock:
                return oponente == .tijeras || oponente == .piedra
            }
        }


    
    
    @IBAction func presionoPiedra(_ sender: Any) {
        
        jugar(usuario: .piedra)

    }
    
    @IBAction func pPapel(_ sender: Any) {
        jugar(usuario: .papel)
    }
    
    
    @IBAction func pTijeras(_ sender: Any) {
        jugar(usuario:.tijeras)
    }
  

    @IBAction func presionoLagarto(_ sender: Any) {
        
        jugar(usuario: .lagarto)
    }
    
    
    @IBAction func presionoSpock(_ sender: Any) {
        
        jugar(usuario: .spock)
        
    }
    
}

