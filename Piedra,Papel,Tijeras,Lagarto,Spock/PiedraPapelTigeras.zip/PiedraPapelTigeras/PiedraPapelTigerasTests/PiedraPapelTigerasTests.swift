//
//  PiedraPapelTigerasTests.swift
//  PiedraPapelTigerasTests
//
//  Created by DEVELOP17 on 22/10/25.
//

import Testing
@testable import PiedraPapelTigeras

struct PiedraPapelTigerasTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
